#ifndef ZCHXECDISPROGRESSWIDGET_H
#define ZCHXECDISPROGRESSWIDGET_H

#include <zchxecdispopupwidget.h>

class zchxEcdisProgressWidget : public zchxECdisPopupWidget
{
    Q_OBJECT
public:
    explicit zchxEcdisProgressWidget(QWidget *parent = 0);

signals:

public slots:
};

#endif // ZCHXECDISPROGRESSWIDGET_H
