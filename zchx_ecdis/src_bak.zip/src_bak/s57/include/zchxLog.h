﻿#ifndef ZCHX_LOGMSH_H
#define ZCHX_LOGMSH_H

#include <QDebug>

#define 	ZCHX_LOGMSG(msg)		qDebug("FILE:%s	FUNC:%s		LINE:%d		%s", __FILE__, __FUNCTION__, __LINE__, (msg))



#endif // !1


