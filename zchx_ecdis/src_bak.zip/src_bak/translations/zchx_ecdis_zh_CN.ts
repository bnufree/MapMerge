<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>CardMouthInfoDialog</name>
    <message>
        <location filename="../cardmouthinfodialog.ui" line="14"/>
        <source>新建自定义区域</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cardmouthinfodialog.ui" line="22"/>
        <source>名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cardmouthinfodialog.ui" line="49"/>
        <source>基建类型</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cardmouthinfodialog.ui" line="57"/>
        <source>单向</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cardmouthinfodialog.ui" line="62"/>
        <source>双向</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cardmouthinfodialog.ui" line="87"/>
        <source>是否开启检测AIS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cardmouthinfodialog.ui" line="95"/>
        <source>是</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cardmouthinfodialog.ui" line="100"/>
        <source>否</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cardmouthinfodialog.ui" line="125"/>
        <location filename="../cardmouthinfodialog.ui" line="133"/>
        <source>预警</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cardmouthinfodialog.ui" line="138"/>
        <source>非预警</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cardmouthinfodialog.ui" line="163"/>
        <source>填充色</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cardmouthinfodialog.ui" line="189"/>
        <source>选择颜色</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cardmouthinfodialog.ui" line="219"/>
        <source>超长:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cardmouthinfodialog.ui" line="229"/>
        <source>米</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cardmouthinfodialog.ui" line="266"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cardmouthinfodialog.ui" line="273"/>
        <source>取消</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChannelInfoDialog</name>
    <message>
        <location filename="../channelinfodialog.ui" line="14"/>
        <source>新增航道</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../channelinfodialog.ui" line="22"/>
        <source>名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../channelinfodialog.ui" line="36"/>
        <source>类型</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../channelinfodialog.ui" line="44"/>
        <source>单向航道</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../channelinfodialog.ui" line="49"/>
        <source>双向航道</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../channelinfodialog.ui" line="54"/>
        <source>限制性航道</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../channelinfodialog.ui" line="59"/>
        <source>其他航道</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../channelinfodialog.ui" line="64"/>
        <source>码头</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../channelinfodialog.ui" line="76"/>
        <location filename="../channelinfodialog.ui" line="84"/>
        <source>预警</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../channelinfodialog.ui" line="89"/>
        <source>非预警</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../channelinfodialog.ui" line="101"/>
        <source>填充色</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../channelinfodialog.ui" line="127"/>
        <source>选择颜色</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../channelinfodialog.ui" line="144"/>
        <source>限速</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../channelinfodialog.ui" line="154"/>
        <source>节</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../channelinfodialog.ui" line="171"/>
        <source>碰撞门限</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../channelinfodialog.ui" line="181"/>
        <location filename="../channelinfodialog.ui" line="208"/>
        <location filename="../channelinfodialog.ui" line="235"/>
        <location filename="../channelinfodialog.ui" line="262"/>
        <location filename="../channelinfodialog.ui" line="289"/>
        <location filename="../channelinfodialog.ui" line="316"/>
        <location filename="../channelinfodialog.ui" line="343"/>
        <location filename="../channelinfodialog.ui" line="370"/>
        <source>米</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../channelinfodialog.ui" line="198"/>
        <source>偏航门限</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../channelinfodialog.ui" line="225"/>
        <source>追越门限</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../channelinfodialog.ui" line="252"/>
        <source>抛锚门限</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../channelinfodialog.ui" line="279"/>
        <source>追越最短距离</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../channelinfodialog.ui" line="306"/>
        <source>追越垂直距离</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../channelinfodialog.ui" line="333"/>
        <source>加速度阀值</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../channelinfodialog.ui" line="360"/>
        <source>加速度差值</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../channelinfodialog.ui" line="381"/>
        <source>逆行预警</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../channelinfodialog.ui" line="389"/>
        <location filename="../channelinfodialog.ui" line="414"/>
        <source>开启</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../channelinfodialog.ui" line="394"/>
        <location filename="../channelinfodialog.ui" line="419"/>
        <source>关闭</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../channelinfodialog.ui" line="406"/>
        <source>超载预警</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../channelinfodialog.ui" line="444"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../channelinfodialog.ui" line="451"/>
        <source>取消</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CoastDataInfoDialog</name>
    <message>
        <location filename="../coastdatainfodialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coastdatainfodialog.ui" line="24"/>
        <source>名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coastdatainfodialog.ui" line="34"/>
        <source>监管机构</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coastdatainfodialog.ui" line="44"/>
        <source>负责人</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coastdatainfodialog.ui" line="54"/>
        <source>深度</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coastdatainfodialog.ui" line="96"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coastdatainfodialog.ui" line="103"/>
        <source>取消</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DefenceInfoDialog</name>
    <message>
        <location filename="../defenceinfodialog.ui" line="14"/>
        <source>新建自定义区域</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defenceinfodialog.ui" line="22"/>
        <source>名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defenceinfodialog.ui" line="49"/>
        <location filename="../defenceinfodialog.ui" line="57"/>
        <source>预警</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defenceinfodialog.ui" line="62"/>
        <source>非预警</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defenceinfodialog.ui" line="87"/>
        <source>类别</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defenceinfodialog.ui" line="95"/>
        <source>准入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defenceinfodialog.ui" line="100"/>
        <source>禁入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defenceinfodialog.ui" line="125"/>
        <source>填充色</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defenceinfodialog.ui" line="151"/>
        <source>选择颜色</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defenceinfodialog.ui" line="181"/>
        <source>抛锚门限:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defenceinfodialog.ui" line="191"/>
        <source>米</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defenceinfodialog.ui" line="221"/>
        <source>限速:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defenceinfodialog.ui" line="231"/>
        <source>节</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defenceinfodialog.ui" line="268"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defenceinfodialog.ui" line="275"/>
        <source>取消</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LocalMarkDlg</name>
    <message>
        <location filename="../localmarkdlg.ui" line="14"/>
        <source>LocationMark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../localmarkdlg.ui" line="26"/>
        <source>localLon:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../localmarkdlg.ui" line="33"/>
        <source>localName:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../localmarkdlg.ui" line="43"/>
        <source>localLat:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../localmarkdlg.ui" line="50"/>
        <source>set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../localmarkdlg.cpp" line="43"/>
        <source>Error Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../localmarkdlg.cpp" line="43"/>
        <source>Please input local mark name!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="43"/>
        <source>中心点经纬度</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="50"/>
        <source>输入纬度值</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="57"/>
        <source>输入经度值</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="64"/>
        <source>层级</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="74"/>
        <source>加载</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="119"/>
        <source>显示图片编号</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="126"/>
        <source>地图数据来源</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="143"/>
        <source>开始下载</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MooringInfoDialog</name>
    <message>
        <location filename="../mooringinfodialog.ui" line="14"/>
        <source>新增锚泊</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mooringinfodialog.ui" line="22"/>
        <source>名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mooringinfodialog.ui" line="49"/>
        <location filename="../mooringinfodialog.ui" line="57"/>
        <source>预警</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mooringinfodialog.ui" line="62"/>
        <source>非预警</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mooringinfodialog.ui" line="87"/>
        <source>类型</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mooringinfodialog.ui" line="95"/>
        <source>90米以下</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mooringinfodialog.ui" line="100"/>
        <source>90-150米</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mooringinfodialog.ui" line="105"/>
        <source>150 -200米</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mooringinfodialog.ui" line="110"/>
        <source>200-300米</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mooringinfodialog.ui" line="115"/>
        <source>超过300米</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mooringinfodialog.ui" line="140"/>
        <source>填充色</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mooringinfodialog.ui" line="166"/>
        <source>选择颜色</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mooringinfodialog.ui" line="196"/>
        <source>位移:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mooringinfodialog.ui" line="206"/>
        <source>米</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mooringinfodialog.ui" line="236"/>
        <source>位移周期:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mooringinfodialog.ui" line="246"/>
        <source>秒</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mooringinfodialog.ui" line="283"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mooringinfodialog.ui" line="290"/>
        <source>取消</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../data_manager/zchxecdisdatamgr.cpp" line="72"/>
        <location filename="../data_manager/zchxecdisdatamgr.cpp" line="120"/>
        <location filename="../data_manager/zchxecdisdatamgr.cpp" line="168"/>
        <location filename="../data_manager/zchxecdisdatamgr.cpp" line="227"/>
        <source>告警</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../data_manager/zchxecdisdatamgr.cpp" line="72"/>
        <source>最多显示%1个关注目标.
%2未添加</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../data_manager/zchxecdisdatamgr.cpp" line="120"/>
        <source>最多显示%1条实时轨迹.
%2未添加</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../data_manager/zchxecdisdatamgr.cpp" line="168"/>
        <source>最多显示%1条历史轨迹.
%2未添加</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../data_manager/zchxecdisdatamgr.cpp" line="227"/>
        <source>最多显示%1条模拟外推数据.
%2未添加</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../element/aiselement.cpp" line="120"/>
        <source>距离: %1米 时间: %2分%3秒</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../element/radarelement.cpp" line="411"/>
        <source>Time: %1H %2M %3S; Diatance: %L4m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../element/radarelement.cpp" line="440"/>
        <source>T%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxmapdownloadrunfunction.cpp" line="18"/>
        <source>/MapData/%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.cpp" line="770"/>
        <source>Rigid Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.cpp" line="774"/>
        <source>Clamped</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.cpp" line="778"/>
        <source>Sliding</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StructureInfoDialog</name>
    <message>
        <location filename="../structureinfodialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../structureinfodialog.ui" line="30"/>
        <source>面积</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../structureinfodialog.ui" line="37"/>
        <source>深度</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../structureinfodialog.ui" line="44"/>
        <source>名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../structureinfodialog.ui" line="86"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../structureinfodialog.ui" line="93"/>
        <source>取消</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TranslationManager</name>
    <message>
        <location filename="../zchxutils.hpp" line="1635"/>
        <source>Tower Rod</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1636"/>
        <source>Navigation Mark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1637"/>
        <source>Island Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1638"/>
        <source>Wire rod</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1639"/>
        <source>Photoelectric instrument</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1640"/>
        <source>UAV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1641"/>
        <source>Defence area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1642"/>
        <source>Position mark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1643"/>
        <source>Patrol and radar station</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1644"/>
        <source>Patrol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1645"/>
        <source>Radar Station</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1646"/>
        <source>AIS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1647"/>
        <source>AIS current position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1648"/>
        <source>AIS history track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1649"/>
        <source>AIS cable touchdown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1650"/>
        <source>Radar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1651"/>
        <source>Radar current position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1652"/>
        <source>Historical track radar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1653"/>
        <source>Radar area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1654"/>
        <source>Radar echoes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1655"/>
        <source>Warning target</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1656"/>
        <source>Route line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1657"/>
        <source>Route cross</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1658"/>
        <source>Multibeam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1659"/>
        <source>Radarvideo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1660"/>
        <source>History Route line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1661"/>
        <source>Current Route line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1662"/>
        <source>Dangerous cirle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1663"/>
        <source>Camera view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1664"/>
        <source>Radar feature_area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1665"/>
        <source>Lon and lat gird</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1666"/>
        <source>GPS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1667"/>
        <source>GPS current position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1668"/>
        <source>GPS history track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1669"/>
        <source>Camera</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1670"/>
        <source>Ship plan line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1671"/>
        <source>Current Ship plan line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1672"/>
        <source>KiloMeter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1673"/>
        <source>Meter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1674"/>
        <source>Foot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1675"/>
        <source>Inch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1676"/>
        <source>NauticalMile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1677"/>
        <source>History AIS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1678"/>
        <source>History Radar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1679"/>
        <source>Special Route Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1680"/>
        <source>High_level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1681"/>
        <source>Image_map</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1682"/>
        <source>Coast Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1683"/>
        <source>Seabed Pipeline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1684"/>
        <source>Structure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1685"/>
        <source>Area Net</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1686"/>
        <source>Channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1687"/>
        <source>Mooring</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1688"/>
        <source>DefineZone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1689"/>
        <source>CardMouth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1690"/>
        <source>AlarmAscend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxutils.hpp" line="1691"/>
        <source>CameraNetGrid</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WarningZoneParaDialog</name>
    <message>
        <location filename="../warningzoneparadialog.ui" line="20"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../warningzoneparadialog.ui" line="43"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../warningzoneparadialog.ui" line="57"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../warningzoneparadialog.ui" line="64"/>
        <source>Not Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../warningzoneparadialog.ui" line="71"/>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../warningzoneparadialog.ui" line="78"/>
        <source>type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../warningzoneparadialog.ui" line="85"/>
        <source>Key Regions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../warningzoneparadialog.ui" line="92"/>
        <source>CheckBox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../warningzoneparadialog.ui" line="133"/>
        <source>Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../warningzoneparadialog.ui" line="140"/>
        <source>Section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../warningzoneparadialog.ui" line="194"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../warningzoneparadialog.ui" line="201"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>qt::CardMouthInfoDialog</name>
    <message>
        <location filename="../cardmouthinfodialog.cpp" line="64"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>qt::ChannelInfoDialog</name>
    <message>
        <location filename="../channelinfodialog.cpp" line="127"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>qt::DefenceInfoDialog</name>
    <message>
        <location filename="../defenceinfodialog.cpp" line="57"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>qt::MainWindow</name>
    <message>
        <location filename="../mainwindow.cpp" line="26"/>
        <source>TMS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="27"/>
        <source>谷歌</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>qt::MooringInfoDialog</name>
    <message>
        <location filename="../mooringinfodialog.cpp" line="68"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>qt::WarningZoneParaDialog</name>
    <message>
        <location filename="../warningzoneparadialog.cpp" line="52"/>
        <source>warning Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../warningzoneparadialog.cpp" line="53"/>
        <source>name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../warningzoneparadialog.cpp" line="54"/>
        <source>type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../warningzoneparadialog.cpp" line="55"/>
        <source>Key Regions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../warningzoneparadialog.cpp" line="56"/>
        <source>Speed Monitoring Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../warningzoneparadialog.cpp" line="57"/>
        <source>speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../warningzoneparadialog.cpp" line="58"/>
        <source>Section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../warningzoneparadialog.cpp" line="59"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../warningzoneparadialog.cpp" line="60"/>
        <source>Not Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../warningzoneparadialog.cpp" line="61"/>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../warningzoneparadialog.cpp" line="62"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../warningzoneparadialog.cpp" line="63"/>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>qt::zchxAisDataMgr</name>
    <message>
        <location filename="../data_manager/zchxaisdatamgr.cpp" line="140"/>
        <source>Time </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../data_manager/zchxaisdatamgr.cpp" line="140"/>
        <source>H </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../data_manager/zchxaisdatamgr.cpp" line="140"/>
        <source>M </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../data_manager/zchxaisdatamgr.cpp" line="141"/>
        <source>S; Distance: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../data_manager/zchxaisdatamgr.cpp" line="459"/>
        <source>相机列表</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../data_manager/zchxaisdatamgr.cpp" line="461"/>
        <source>画中画</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../data_manager/zchxaisdatamgr.cpp" line="462"/>
        <source>船队</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../data_manager/zchxaisdatamgr.cpp" line="463"/>
        <source>模拟外推</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../data_manager/zchxaisdatamgr.cpp" line="464"/>
        <source>历史轨迹</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../data_manager/zchxaisdatamgr.cpp" line="465"/>
        <source>实时轨迹</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../data_manager/zchxaisdatamgr.cpp" line="466"/>
        <source>黑名单</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../data_manager/zchxaisdatamgr.cpp" line="467"/>
        <source>白名单</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../data_manager/zchxaisdatamgr.cpp" line="468"/>
        <source>CPA跟踪</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../data_manager/zchxaisdatamgr.cpp" line="469"/>
        <source>联动</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>qt::zchxMapWidget</name>
    <message>
        <location filename="../zchxmapwidget.cpp" line="610"/>
        <source>提示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxmapwidget.cpp" line="611"/>
        <source>是否更新当前的相机网格信息?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxmapwidget.cpp" line="613"/>
        <source>确认</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxmapwidget.cpp" line="614"/>
        <source>取消</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxmapwidget.cpp" line="658"/>
        <source>Scroll     </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxmapwidget.cpp" line="671"/>
        <source>Screen Shot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxmapwidget.cpp" line="672"/>
        <source>Pick Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxmapwidget.cpp" line="673"/>
        <source>Frame Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxmapwidget.cpp" line="674"/>
        <source>Ship Siumtion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxmapwidget.cpp" line="675"/>
        <source>Location Mark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxmapwidget.cpp" line="676"/>
        <source>Fixed Reference Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxmapwidget.cpp" line="677"/>
        <source>热点</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxmapwidget.cpp" line="687"/>
        <location filename="../zchxmapwidget.cpp" line="708"/>
        <location filename="../zchxmapwidget.cpp" line="713"/>
        <location filename="../zchxmapwidget.cpp" line="718"/>
        <location filename="../zchxmapwidget.cpp" line="723"/>
        <location filename="../zchxmapwidget.cpp" line="729"/>
        <location filename="../zchxmapwidget.cpp" line="734"/>
        <location filename="../zchxmapwidget.cpp" line="742"/>
        <location filename="../zchxmapwidget.cpp" line="748"/>
        <location filename="../zchxmapwidget.cpp" line="756"/>
        <location filename="../zchxmapwidget.cpp" line="761"/>
        <location filename="../zchxmapwidget.cpp" line="769"/>
        <location filename="../zchxmapwidget.cpp" line="774"/>
        <location filename="../zchxmapwidget.cpp" line="782"/>
        <location filename="../zchxmapwidget.cpp" line="789"/>
        <location filename="../zchxmapwidget.cpp" line="794"/>
        <source>End draw</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxmapwidget.cpp" line="688"/>
        <location filename="../zchxmapwidget.cpp" line="696"/>
        <location filename="../zchxmapwidget.cpp" line="704"/>
        <location filename="../zchxmapwidget.cpp" line="709"/>
        <location filename="../zchxmapwidget.cpp" line="714"/>
        <location filename="../zchxmapwidget.cpp" line="719"/>
        <location filename="../zchxmapwidget.cpp" line="724"/>
        <location filename="../zchxmapwidget.cpp" line="730"/>
        <location filename="../zchxmapwidget.cpp" line="735"/>
        <location filename="../zchxmapwidget.cpp" line="743"/>
        <location filename="../zchxmapwidget.cpp" line="749"/>
        <location filename="../zchxmapwidget.cpp" line="757"/>
        <location filename="../zchxmapwidget.cpp" line="762"/>
        <location filename="../zchxmapwidget.cpp" line="770"/>
        <location filename="../zchxmapwidget.cpp" line="775"/>
        <location filename="../zchxmapwidget.cpp" line="783"/>
        <location filename="../zchxmapwidget.cpp" line="790"/>
        <location filename="../zchxmapwidget.cpp" line="795"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxmapwidget.cpp" line="695"/>
        <location filename="../zchxmapwidget.cpp" line="703"/>
        <source>End edit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>qt::zchxUserDefinesDataMgr</name>
    <message>
        <location filename="../zchxuserdefinesdatamgr.cpp" line="504"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxuserdefinesdatamgr.cpp" line="505"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxuserdefinesdatamgr.cpp" line="506"/>
        <source>WARRING ZONE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../zchxuserdefinesdatamgr.cpp" line="507"/>
        <source>(Default 5 minute warning)Name:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
