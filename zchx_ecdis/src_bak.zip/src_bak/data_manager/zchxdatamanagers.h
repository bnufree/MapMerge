#ifndef ZCHXDATAMANAGERS_H
#define ZCHXDATAMANAGERS_H

#include "zchxaisdatamgr.h"
#include "zchxradardatamgr.h"
#include "zchxradarsitedatamgr.h"
#include "zchxcameradatamgr.h"
#include "zchxroddatamgr.h"
#include "zchxcameraviewdatamgr.h"
#include "zchxvideotargetdatamgr.h"
#include "zchxuserdefinesdatamgr.h"
#include "zchxnetgridmgr.h"
#include "zchxradarrectmgr.h"
#include "zchxradarvideomgr.h"

#endif // ZCHXDATAMANAGERS_H
